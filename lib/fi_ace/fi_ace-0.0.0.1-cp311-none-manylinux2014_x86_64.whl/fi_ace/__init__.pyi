"""
module
"""
from __future__ import annotations
import typing
__all__: list[str] = ['AC', 'ctrl_mode_e', 'param_t', 'param_type_e', 'pvctte_t', 'ret_e', 'sdk_config_t']
class AC:
    @staticmethod
    def EthercatIpcInit(read_only: bool) -> ret_e:
        ...
    def DisableControl(self, timeout_ms: typing.SupportsFloat = 5, max_retry: typing.SupportsInt = 1) -> ret_e:
        ...
    def EnableControl(self, ctrl_mode: ctrl_mode_e, timeout_ms: typing.SupportsFloat = 5, max_retry: typing.SupportsInt = 1) -> ret_e:
        ...
    def GetPVCTTe(self, rx_PVCTTe: pvctte_t) -> ret_e:
        ...
    def GetParam(self, param: param_t) -> ret_e:
        ...
    def InitByAlias(self, slave_alias: typing.SupportsInt) -> ret_e:
        ...
    def SetCurrentNoAck(self, c_A: typing.SupportsFloat) -> ret_e:
        ...
    def SetPDPositionVelocityNoAck(self, p_rad: typing.SupportsFloat, v_radps: typing.SupportsFloat = 0, t_ff_Nm: typing.SupportsFloat = 0) -> ret_e:
        ...
    def SetParam(self, param: param_t) -> ret_e:
        ...
    def SetPositionNoAck(self, p_rad: typing.SupportsFloat, v_ff_radps: typing.SupportsFloat = 0, t_ff_Nm: typing.SupportsFloat = 0) -> ret_e:
        ...
    def SetTorqueNoAck(self, t_Nm: typing.SupportsFloat) -> ret_e:
        ...
    def SetVelocityNoAck(self, v_radps: typing.SupportsFloat, t_ff_Nm: typing.SupportsFloat = 0) -> ret_e:
        ...
    def __init__(self) -> None:
        ...
class ctrl_mode_e:
    """
    Members:
    
      NONE : 
        无控制模式
    
      CURRENT_MODE : 
        电流控制模式
    
      VELOCITY_MODE_C : 
        电流速度控制模式
    
      POSITION_MODE_C : 
        电流位置控制模式
    
      TORQUE_MODE : 
        转矩控制模式
    
      VELOCITY_MODE_T : 
        转矩速度控制模式
    
      POSITION_MODE_T : 
        转矩位置控制模式
    
      PD_MODE : 
        转矩PD控制模式
    """
    CURRENT_MODE: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.CURRENT_MODE: 1>
    NONE: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.NONE: 0>
    PD_MODE: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.PD_MODE: 7>
    POSITION_MODE_C: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.POSITION_MODE_C: 3>
    POSITION_MODE_T: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.POSITION_MODE_T: 6>
    TORQUE_MODE: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.TORQUE_MODE: 4>
    VELOCITY_MODE_C: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.VELOCITY_MODE_C: 2>
    VELOCITY_MODE_T: typing.ClassVar[ctrl_mode_e]  # value = <ctrl_mode_e.VELOCITY_MODE_T: 5>
    __members__: typing.ClassVar[dict[str, ctrl_mode_e]]  # value = {'NONE': <ctrl_mode_e.NONE: 0>, 'CURRENT_MODE': <ctrl_mode_e.CURRENT_MODE: 1>, 'VELOCITY_MODE_C': <ctrl_mode_e.VELOCITY_MODE_C: 2>, 'POSITION_MODE_C': <ctrl_mode_e.POSITION_MODE_C: 3>, 'TORQUE_MODE': <ctrl_mode_e.TORQUE_MODE: 4>, 'VELOCITY_MODE_T': <ctrl_mode_e.VELOCITY_MODE_T: 5>, 'POSITION_MODE_T': <ctrl_mode_e.POSITION_MODE_T: 6>, 'PD_MODE': <ctrl_mode_e.PD_MODE: 7>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class param_t:
    type: param_type_e
    def __init__(self) -> None:
        ...
    @property
    def value(self) -> float:
        ...
    @value.setter
    def value(self, arg0: typing.SupportsFloat) -> None:
        ...
class param_type_e:
    """
    Members:
    
      PD_KP
    
      PD_KD
    """
    PD_KD: typing.ClassVar[param_type_e]  # value = <param_type_e.PD_KD: 1>
    PD_KP: typing.ClassVar[param_type_e]  # value = <param_type_e.PD_KP: 0>
    __members__: typing.ClassVar[dict[str, param_type_e]]  # value = {'PD_KP': <param_type_e.PD_KP: 0>, 'PD_KD': <param_type_e.PD_KD: 1>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class pvctte_t:
    def __init__(self) -> None:
        ...
    @property
    def cur(self) -> float:
        ...
    @cur.setter
    def cur(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def pos(self) -> float:
        ...
    @pos.setter
    def pos(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def tor(self) -> float:
        ...
    @tor.setter
    def tor(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def tor_e(self) -> float:
        ...
    @tor_e.setter
    def tor_e(self, arg0: typing.SupportsFloat) -> None:
        ...
    @property
    def vel(self) -> float:
        ...
    @vel.setter
    def vel(self, arg0: typing.SupportsFloat) -> None:
        ...
class ret_e:
    """
    Members:
    
      SUCCESS : 
        操作成功
    
      TIMEOUT : 
        操作超时
    
      SHM_INIT_FAILED : 
        共享内存初始化失败
    
      SHM_VERSION_ERROR : 
        共享内存版本不兼容
    
      EC_SLAVE_NOT_FOUND : 
        没有找到对应的从站
    
      EC_PDO_READ_FAILED : 
        读取 PDO 失败
    
      EC_PDO_WRITE_FAILED : 
        写入 PDO 失败
    
      UNKNOWN_CIA402_STATUS : 
        未知的 CIA402 状态
    
      UNSUPPORTED_MODE_OF_OP : 
        不支持的控制模式
    
      UNSUPPORTED_PARAM_TYPE : 
        不支持的参数类型
    
      INVALID_PARAM_VALUE : 
        无效的参数值
    """
    EC_PDO_READ_FAILED: typing.ClassVar[ret_e]  # value = <ret_e.EC_PDO_READ_FAILED: 210>
    EC_PDO_WRITE_FAILED: typing.ClassVar[ret_e]  # value = <ret_e.EC_PDO_WRITE_FAILED: 220>
    EC_SLAVE_NOT_FOUND: typing.ClassVar[ret_e]  # value = <ret_e.EC_SLAVE_NOT_FOUND: 200>
    INVALID_PARAM_VALUE: typing.ClassVar[ret_e]  # value = <ret_e.INVALID_PARAM_VALUE: 410>
    SHM_INIT_FAILED: typing.ClassVar[ret_e]  # value = <ret_e.SHM_INIT_FAILED: 100>
    SHM_VERSION_ERROR: typing.ClassVar[ret_e]  # value = <ret_e.SHM_VERSION_ERROR: 101>
    SUCCESS: typing.ClassVar[ret_e]  # value = <ret_e.SUCCESS: 0>
    TIMEOUT: typing.ClassVar[ret_e]  # value = <ret_e.TIMEOUT: 1>
    UNKNOWN_CIA402_STATUS: typing.ClassVar[ret_e]  # value = <ret_e.UNKNOWN_CIA402_STATUS: 300>
    UNSUPPORTED_MODE_OF_OP: typing.ClassVar[ret_e]  # value = <ret_e.UNSUPPORTED_MODE_OF_OP: 310>
    UNSUPPORTED_PARAM_TYPE: typing.ClassVar[ret_e]  # value = <ret_e.UNSUPPORTED_PARAM_TYPE: 400>
    __members__: typing.ClassVar[dict[str, ret_e]]  # value = {'SUCCESS': <ret_e.SUCCESS: 0>, 'TIMEOUT': <ret_e.TIMEOUT: 1>, 'SHM_INIT_FAILED': <ret_e.SHM_INIT_FAILED: 100>, 'SHM_VERSION_ERROR': <ret_e.SHM_VERSION_ERROR: 101>, 'EC_SLAVE_NOT_FOUND': <ret_e.EC_SLAVE_NOT_FOUND: 200>, 'EC_PDO_READ_FAILED': <ret_e.EC_PDO_READ_FAILED: 210>, 'EC_PDO_WRITE_FAILED': <ret_e.EC_PDO_WRITE_FAILED: 220>, 'UNKNOWN_CIA402_STATUS': <ret_e.UNKNOWN_CIA402_STATUS: 300>, 'UNSUPPORTED_MODE_OF_OP': <ret_e.UNSUPPORTED_MODE_OF_OP: 310>, 'UNSUPPORTED_PARAM_TYPE': <ret_e.UNSUPPORTED_PARAM_TYPE: 400>, 'INVALID_PARAM_VALUE': <ret_e.INVALID_PARAM_VALUE: 410>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: typing.SupportsInt) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: typing.SupportsInt) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class sdk_config_t:
    @property
    def DEFAULT_MAX_RETRY(self) -> int:
        """
            用户默认最大重试次数
        """
    @DEFAULT_MAX_RETRY.setter
    def DEFAULT_MAX_RETRY(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def DEFAULT_TIMEOUT_MS(self) -> int:
        """
            用户默认超时时间, 单位毫秒
        """
    @DEFAULT_TIMEOUT_MS.setter
    def DEFAULT_TIMEOUT_MS(self, arg0: typing.SupportsInt) -> None:
        ...
    @property
    def SDK_HEADER_VERSION(self) -> int:
        """
            SDK 头文件版本
        """
