import sys
import os
import importlib.util
import glob

py_module_name = "fi_ace"

_pkg_dir = os.path.dirname(__file__)

if sys.platform.startswith("linux"):
    pattern = os.path.join(
        _pkg_dir, f"{py_module_name}.cpython-{sys.version_info.major}{sys.version_info.minor}*.so")
elif sys.platform.startswith("win"):
    pattern = os.path.join(
        _pkg_dir, f"{py_module_name}.cp{sys.version_info.major}{sys.version_info.minor}*.pyd")

_candidates = glob.glob(pattern)
if not _candidates:
    raise ImportError(
        f"Cannot find {py_module_name} extension for Python {sys.version_info.major}.{sys.version_info.minor}")
_so_path = _candidates[0]

spec = importlib.util.spec_from_file_location(py_module_name, _so_path)
_mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(_mod)

globals().update(vars(_mod))
